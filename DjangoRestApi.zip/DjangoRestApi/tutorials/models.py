from django.db import models
from datetime import datetime


# Create your models here.

class User_Details( models.Model ):
    email = models.EmailField(primary_key=True, )
    password = models.CharField( max_length=100, blank=False, default='' )
    longitude = models.CharField( max_length=200, blank=False, default='' )
    latitude = models.CharField( max_length=200, blank=False, default='' )


class Ad( models.Model ):
    ad_id = models.CharField( max_length=100, primary_key=True, )


class Ad_location( models.Model ):
    ad = models.ForeignKey( 'Ad', on_delete=models.CASCADE )
    longitude = models.CharField( max_length=200, blank=False, default='' )
    latitude = models.CharField( max_length=200, blank=False, default='' )
    date = models.DateTimeField( default=datetime.now, blank=True )
