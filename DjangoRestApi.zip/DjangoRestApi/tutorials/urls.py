from django.conf.urls import url
from tutorials import views

urlpatterns = [
    url( r'^api/ads$', views.ads_list ),
    url( r'^api/users$', views.user_list ),
    url( r'^api/all/ads$', views.unique_ads_list ),
]
