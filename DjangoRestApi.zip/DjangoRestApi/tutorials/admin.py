from django.contrib import admin
from tutorials.models import User_Details, Ad, Ad_location

# Register your models here.
admin.site.register( User_Details )
admin.site.register( Ad )
admin.site.register( Ad_location )
