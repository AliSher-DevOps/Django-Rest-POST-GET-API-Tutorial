from django.http.response import JsonResponse
from rest_framework.parsers import JSONParser
from rest_framework import status

from tutorials.models import User_Details, Ad, Ad_location
from tutorials.serializers import AdSerializer, UserSerializer, AdLocationSerializer
from rest_framework.decorators import api_view

@api_view( ['GET', 'POST'] )
def ads_list(request):
    if request.method == 'GET':
        ads_location = Ad_location.objects.all()
        ads_location_serializer = AdLocationSerializer( ads_location, many=True )
        return JsonResponse( ads_location_serializer.data, safe=False )
        # 'safe=False' for objects serialization

    elif request.method == 'POST':
        adds_data = JSONParser().parse( request )
        data = {
            "ad_id": adds_data['ad_id']
        }
        if Ad.objects.filter( ad_id=adds_data['ad_id'] ).exists():
            Ad_location.objects.create(
                ad=Ad.objects.filter( ad_id=adds_data['ad_id'] ).first(),
                longitude=adds_data['longitude'],
                latitude=adds_data['latitude'],
            ).save()
            return JsonResponse( adds_data, status=status.HTTP_201_CREATED )
        else:
            adds_serializer = AdSerializer( data=data )
            if adds_serializer.is_valid():
                adds_serializer.save()
                Ad_location.objects.create(
                    ad=Ad.objects.filter( ad_id=adds_data['ad_id'] ).first(),
                    longitude=adds_data['longitude'],
                    latitude=adds_data['latitude'],
                ).save()
                return JsonResponse( adds_data, status=status.HTTP_201_CREATED )
            return JsonResponse( adds_serializer.errors, status=status.HTTP_400_BAD_REQUEST )


@api_view( ['GET', 'POST'] )
def user_list(request):
    if request.method == 'GET':
        users = User_Details.objects.all()
        users_serializer = UserSerializer( users, many=True )
        return JsonResponse( users_serializer.data, safe=False )
        # 'safe=False' for objects serialization

    elif request.method == 'POST':
        users_data = JSONParser().parse( request )
        users_serializer = UserSerializer( data=users_data )
        if users_serializer.is_valid():
            users_serializer.save()
            return JsonResponse( users_serializer.data, status=status.HTTP_201_CREATED )
        return JsonResponse( users_serializer.errors, status=status.HTTP_400_BAD_REQUEST )


@api_view( ['GET', 'DELETE'] )
def unique_ads_list(request):
    if request.method == 'GET':
        ads = Ad.objects.all()
        ads_serializer = AdSerializer( ads, many=True )
        return JsonResponse( ads_serializer.data, safe=False )
    elif request.method == 'DELETE':
        count = Ad.objects.all().delete()
        return JsonResponse( {'message': '{} Ads were deleted successfully!'.format( count[0] )},
                             status=status.HTTP_204_NO_CONTENT )



