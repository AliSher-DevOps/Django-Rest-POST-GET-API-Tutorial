from rest_framework import serializers
from tutorials.models import Ad, User_Details,Ad_location


class AdSerializer( serializers.ModelSerializer ):
    class Meta:
        model = Ad
        fields = ('ad_id',)


class AdLocationSerializer( serializers.ModelSerializer ):
    class Meta:
        model = Ad_location
        fields = ('ad',
                  'longitude',
                  'latitude',
                  'date')


class UserSerializer( serializers.ModelSerializer ):
    class Meta:
        model = User_Details
        fields = ('email',
                  'password',
                  'longitude',
                  'latitude')

